#pragma once
#include <Core/Scene/WorldBase.h>

class World1 : public WorldBase
{
public:
	World1();
	virtual ~World1() override;

};
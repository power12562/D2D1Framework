#pragma once
#include <Framework/WinGameApp.h>

class MyGameApp : public WinGameApp
{
public:
	MyGameApp();
	virtual ~MyGameApp() override;
};